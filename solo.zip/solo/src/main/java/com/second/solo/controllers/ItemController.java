package com.second.solo.controllers;
 
import java.util.List;

import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

import com.second.solo.models.Item;
import com.second.solo.models.Shelf;
import com.second.solo.models.User;
import com.second.solo.services.ItemService;
import com.second.solo.services.ShelfService;
import com.second.solo.services.UserService;

@Controller
public class ItemController {

	
	@Autowired
	private ItemService itemService;
	
	@Autowired
	private ShelfService shelfService;
	
	
	@Autowired
	private final UserService userService= null;
	
 
	//1
    @GetMapping("/items" )
    public String itempage(Model model,HttpSession session) {
    	
		 // If there is no attribute "user_id" on session, then redirect to index page
	    Long userId = (Long) session.getAttribute("userId");
	    if (userId == null) {
	        return "redirect:/";
	    }
	     else {
	        User currentUser = this.userService.findById(userId); 
	        List<Item> joinItems = itemService.allItems();
	        
	        model.addAttribute("user",currentUser);
	         
 		    model.addAttribute("myItems", joinItems); 
		 
	        return "itemtable.jsp";
	    }
        
    }
	
    //2
    @GetMapping("/items/{itemId}")
	public String sItem (Model model,
							@PathVariable("itemId") Long itemId) {
		
		Item item = itemService.findItem(itemId);
		model.addAttribute("item",item);

		return "detailitem.jsp";
	}
	 
	
   	//4 .. add new item
	@GetMapping("/items/new")
	public String newItem(@ModelAttribute("addNewItem") Item item,HttpSession session,Model model) {
		 List<Shelf> joinShelves = shelfService.allShelves();
		 model.addAttribute("shelves", joinShelves);// for add shelf as a down arrow
		  Long id = (Long)session.getAttribute("userId");
		  User thisUser = userService.findById(id);
		  model.addAttribute("shelf", joinShelves);
		  model.addAttribute("thisUser",  thisUser);
		return "additem.jsp";
	}
  		
  		
	//2  CODE TO MAKE A NEW user AND SAVE TO THE DB  1
	@PostMapping("/items")
	public String addItem(@Valid @ModelAttribute("item") Item item,
							 	BindingResult result) {
		if(result.hasErrors()) {
			return "additem.jsp";
		}
		else {
			
			itemService.creatItem(item);
			return "redirect:/items";
		}
	}
	
	//5 edit
	@GetMapping("/items/{id}/edit")
	   public String editItem(@PathVariable("id") Long id, Model model) {
	       Item item = itemService.findItem(id);
	       model.addAttribute("item", item); 
	       return "edititem.jsp";
	   }
	

	//6
	@PostMapping("/items/{id}")
	   public String updateItem(@Valid @ModelAttribute("item") Item item, BindingResult result) {
	       if (result.hasErrors()) {
	           return "edititem.jsp";
	       } else { 
	           itemService.saveItem(item);
	           return "redirect:/items";
	       }
	   }
	
	
	//delete
	@GetMapping("/items/delete/{id}")
	  public String destroyItem(@PathVariable("id") Long id) {
		itemService.deleteItem(id);
	      return "redirect:/items";
	  }
	
 
	
	
}
