package com.second.ninjaGame;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class NinjaGameApplicationTests {

	@Test
	void contextLoads() {
	}

}
