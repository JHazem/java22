package com.second.testexam;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TestexamApplicationTests {

	@Test
	void contextLoads() {
	}

}
