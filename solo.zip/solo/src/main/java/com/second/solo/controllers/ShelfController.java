package com.second.solo.controllers;
 

import java.util.List;

import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

import com.second.solo.models.Item;
import com.second.solo.models.Shelf;
import com.second.solo.models.User;
import com.second.solo.services.ItemService;
import com.second.solo.services.ShelfService;
import com.second.solo.services.UserService;

@Controller
public class ShelfController {


	@Autowired
	private ShelfService shelfService;
	
	@Autowired
	private ItemService itemService;
	
	@Autowired
	private final UserService userService= null;
	

	//1
    @GetMapping("/shelves" )
    public String shelfpage(Model model,HttpSession session) {
    	
		 // If there is no attribute "user_id" on session, then redirect to index page
	    Long userId = (Long) session.getAttribute("userId");
	    if (userId == null) {
	        return "redirect:/";
	    }
	     else {
	        User currentUser = this.userService.findById(userId); 
 	         List<Shelf>  shelves = shelfService.allShelves();
 	         
 	         model.addAttribute("user",currentUser);
 		 
 		    model.addAttribute("shelves", shelves); 
		 
	        return "shelftable.jsp";
	    }
        
    }
	

    //2
    @GetMapping("/shelves/{shelfId}")
	public String nShelf( Model model,
							@PathVariable("shelfId") Long shelfId) {
		
		Shelf shelf = shelfService.findShelf(shelfId); 
		model.addAttribute("shelf",shelf);

		return "detailshelf.jsp";
	}
	
    
    //4 .. add new shelf
	@GetMapping("/shelves/new")
	public String newShelf(@ModelAttribute("addNewShelf") Shelf shelf,HttpSession session,Model model) {
 		List<Item> itemsList = itemService.allItems();
		
		  Long id = (Long)session.getAttribute("userId");
		  User thisUser = userService.findById(id);
		  model.addAttribute("items", itemsList);
		  model.addAttribute("thisUser",  thisUser);
		return "addshelf.jsp";
	}
  		
	
	//4  CODE TO MAKE A NEW user AND SAVE TO THE DB  1
	@PostMapping("/shelves")
	public String addShelf(@Valid @ModelAttribute("shelf") Shelf shelf,
							 	BindingResult result) {
		if(result.hasErrors()) { 
			return "addshelf.jsp";
		}
		else {
	 
			shelfService.creatShelf(shelf); 
			return "redirect:/shelves";
			}
		}
		
		//5 edit
		@GetMapping("/shelves/{id}/edit")
		   public String editShelf(@PathVariable("id") Long id, Model model) {
		       Shelf shelf = shelfService.findShelf(id);
		       model.addAttribute("shelf", shelf);
		       //System.out.println(shelf.getUser().getId());
		       return "editshelf.jsp";
		   }
		
	
		//6
		@PostMapping("/shelves/{id}")
		   public String updateShelf(@Valid @ModelAttribute("shelf") Shelf shelf, BindingResult result) {
		       if (result.hasErrors()) {
		           return "editshelf.jsp";
		       } else { 
		           shelfService.saveShelf(shelf);
		           return "redirect:/shelves";
		       }
		   }
		
		
		//delete
		@GetMapping("/shelves/delete/{id}")
		  public String destroyShelf(@PathVariable("id") Long id) {
			shelfService.deleteShelf(id);
		      return "redirect:/shelves";
		  }
		
 
	
	
	
}
