package com.second.relationships.controllers;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import com.second.relationships.models.Dormitory;
import com.second.relationships.models.Student;
import com.second.relationshipsservices.StudentDormService;

@Controller
public class HomeController {

	@Autowired
	private StudentDormService studDormServ;
	

	//1  dorm p
	@GetMapping("/dorms/new")
	public String newDorm(@ModelAttribute("addNewDorm") Dormitory dorm) {
		return "newdorm.jsp";
	}
	
	//1  student p
	@GetMapping("/students/new")
	public String newStud(@ModelAttribute("addNewStud") Student stud,Model model) {
		model.addAttribute("dorms", studDormServ.getAllDormitories());
		return "newstud.jsp";
	}
	
	//2  CODE TO MAKE A NEW dorm AND SAVE TO THE DB
	@PostMapping("/newdorm1")
	public String addDorm(@Valid @ModelAttribute("addNewDorm") Dormitory dorm, BindingResult result) {
		if(result.hasErrors()) {
			return "newstud.jsp";
		}
		else {
			studDormServ.allDormitories(dorm);
			return "redirect:/stud/new";
		}
	}
		
		//2 CODE TO MAKE A NEW Student AND SAVE TO THE DB
		@PostMapping("addstud")
		public String addStudent(@Valid @ModelAttribute("addNewStud") Student stud, BindingResult result) {
			if(result.hasErrors()) {
				return "newstud.jsp";
			}
			else {
				studDormServ.allStudents(stud);
				return "newdorm.jsp";
			}
		}
		
	
	
	
}
