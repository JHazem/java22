package com.second.relationshipsservices;

import java.util.List;
import java.util.Optional;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.second.relationships.Repositories.DormRepository;
import com.second.relationships.Repositories.StudentRepository;
import com.second.relationships.models.Dormitory;
import com.second.relationships.models.Student;

@Service
public class StudentDormService {

	@Autowired
	private final DormRepository dormRepo; 
	private final StudentRepository studRepo; 
	
	public StudentDormService(DormRepository dormRepo,StudentRepository studRepo) {
		this.dormRepo = dormRepo;
		this.studRepo = studRepo;
	}
	
	//4-2   List all student
	public List<Student> getAllStudents(){
		return studRepo.findAll();
	}
	
	//4-3 retrieves a student
	public Student findStudent (Long id) {
		Optional <Student> optionalStudent= studRepo.findById(id);
		
		if(optionalStudent.isPresent()) {
			return optionalStudent.get();
		}else {
			return null;
			}
		}
	
		//4-4    creates  dorm
		public Dormitory createDorm(Dormitory d) {
			return dormRepo.save(d);
		}
		
		//4-4    creates student
		public Student createStud(Student s) {
			return studRepo.save(s);
		}

	
		public void allDormitories(@Valid Dormitory dorm) {
			// TODO Auto-generated method stub
			dormRepo.save(dorm);
		}
	
		public void allStudents(@Valid Student stud) {
			// TODO Auto-generated method stub
			studRepo.save(stud);
		}
	
		public Object getAllDormitories() {
			// TODO Auto-generated method stub
			return null;
		}

	
	
	
	
	
}
