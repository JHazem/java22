package com.second.tvshows;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TvshowsApplicationTests {

	@Test
	void contextLoads() {
	}

}
