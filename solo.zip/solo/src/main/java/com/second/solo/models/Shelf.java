package com.second.solo.models;

import java.util.Date;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.PrePersist;
import javax.persistence.PreUpdate;
import javax.persistence.Table;
import javax.validation.constraints.NotBlank;

@Entity
@Table(name="shelves")
public class Shelf {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    
    @NotBlank(message="  Name is required!")
    private String shelfName;  
    
    
    @NotBlank(message="Must not be blank")
    private String description;  
    
    @NotBlank(message="Must not be blank")
    private String postedDate; 
    
    
	 @Column(updatable=false)
	 private Date createdAt;
	 private Date updatedAt;
	 

	 @ManyToOne(fetch = FetchType.LAZY)
     @JoinColumn(name="user_id")
	 private User user;
	  
	 // One to many Link to item
	 @OneToMany(mappedBy="myshelf", fetch = FetchType.LAZY)
	 private List<Item> items;
	 
 	 @PrePersist
 	 protected void onCreate(){
        this.createdAt = new Date();
 	 }
 	 
 	 @PreUpdate
 	 protected void onUpdate(){
        this.updatedAt = new Date();
 	 }
	    
 
	 
	 public Shelf() { 
	 }

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getShelfName() {
		return shelfName;
	}

	public void setShelfName(String shelfName) {
		this.shelfName = shelfName;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public Date getCreatedAt() {
		return createdAt;
	}

	public void setCreatedAt(Date createdAt) {
		this.createdAt = createdAt;
	}

	public Date getUpdatedAt() {
		return updatedAt;
	}

	public void setUpdatedAt(Date updatedAt) {
		this.updatedAt = updatedAt;
	}

	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}
 
	public String getPostedDate() {
		return postedDate;
	}

	public void setPostedDate(String postedDate) {
		this.postedDate = postedDate;
	}

	public List<Item> getItems() {
		return items;
	}

	public void setItems(List<Item> items) {
		this.items = items;
	}
    
    
    
    
}
