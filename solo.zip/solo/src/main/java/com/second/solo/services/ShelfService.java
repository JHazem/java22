package com.second.solo.services;

import java.util.List;
import java.util.Optional;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
 
import com.second.solo.models.Shelf;
import com.second.solo.models.User;
import com.second.solo.repositories.ShelfRepository; 

@Service
public class ShelfService {


	@Autowired
	private ShelfRepository shelfRepo;
	
 
	
	//4-2   List all the shelf
	public List<Shelf> allShelves(){
		return shelfRepo.findAll();
	}
	
    //Find user by id
	public Shelf findById(Long id) {
		
		return shelfRepo.findById(id).orElse(null);
	}

	//4-3 retrieves a shelf
	public Shelf findShelf(Long id) {
		
		Optional<Shelf> optionalShelf = shelfRepo.findById(id);
		
		if(optionalShelf.isPresent()) {
			return optionalShelf.get();
		}
		else {
			return null;
		}
	} 
	
	 //4-4    creates a Shelf
		public Shelf creatShelf(Shelf p) {
			return shelfRepo.save(p);
		}
	
		public Shelf saveShelf(@Valid Shelf shelf) {
			 
			return shelfRepo.save(shelf);
		}

		// cam
		public void addUser(Shelf shelf, User k) {
			k.getShelves().add(shelf);
			shelfRepo.save(shelf);
		}
	
		//4-5 delete
		public void deleteShelf(Long id) {
			shelfRepo.deleteById(id);
		}
		 
 
		
	
}
