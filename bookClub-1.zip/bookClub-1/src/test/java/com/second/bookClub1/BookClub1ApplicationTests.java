package com.second.bookClub1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BookClub1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
