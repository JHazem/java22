package com.second.thirdexam1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Thirdexam1Application {

	public static void main(String[] args) {
		SpringApplication.run(Thirdexam1Application.class, args);
	}

}
