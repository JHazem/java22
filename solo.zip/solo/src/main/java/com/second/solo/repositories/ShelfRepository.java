package com.second.solo.repositories;

import java.util.List;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.second.solo.models.Shelf; 

@Repository
public interface ShelfRepository extends CrudRepository<Shelf, Long>{
 
 
	List<Shelf> findAll();

//	
//	List<Shelf> findAllByJointNotContains(User user);
//	List<Shelf> findAllByJointContains(User user);
}
