package com.second.saveTravels.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.second.saveTravels.models.Expense;
import com.second.saveTravels.services.ExpenseService;

@RestController
public class ExpensesApi {
	
	@Autowired
	private final ExpenseService expService;
	
	public ExpensesApi(ExpenseService expService) {
		this.expService = expService;
	}

	 @RequestMapping("/api/expenses")
	 public List<Expense> index() {
	     return expService.allExpenses();
	 }
	
	 //Create
	 @RequestMapping(value="/api/expense", method=RequestMethod.POST)
	 public Expense create( @RequestParam(value="expense") String expenseName,
			 				@RequestParam(value="vender") String vender, 
			 				@RequestParam(value="amount") Integer amount) {
		 
		 Expense expense = new Expense(expenseName, vender, amount);
	     return expService.createExpense(expense);
	 }
	 
	 //Show
	 @RequestMapping("/api/book/{id}")
	 public Expense show(@PathVariable("id") Long id) {
		 Expense expense = expService.findExpense(id);
	     return expense;
	 }
	 
	 
	 // other methods removed for brevity
	 @RequestMapping(value="/api/expense/update/{id}", method=RequestMethod.PUT)
	 public Expense update(@PathVariable("id") Long id, @RequestParam(value="expense") String expenseName,
														@RequestParam(value="vender") String vender, 
														@RequestParam(value="amount") Integer amount) {
		 Expense expense = expService.updateExpense(id,expenseName, vender, amount);
	     return expense;
	 }
	 
	 @RequestMapping(value="/api/expense/delete/{id}", method=RequestMethod.DELETE)
	 public void destroy(@PathVariable("id") Long id) {
	     expService.deleteExpense(id);
	 }
	 
	 @DeleteMapping("{id}")
	 public  ResponseEntity<String> deletExpense(@PathVariable("id") long id){
		 expService.deleteExpense(id);
		 return new ResponseEntity<String>("Expense deleted successfully!", HttpStatus.OK);
	 }
	 
 
}












