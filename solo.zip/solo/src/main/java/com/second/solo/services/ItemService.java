package com.second.solo.services;

import java.util.List;
import java.util.Optional;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired; 
import org.springframework.stereotype.Service;

import com.second.solo.models.Item;
import com.second.solo.models.User;
import com.second.solo.repositories.ItemRepository;

 
@Service
public class ItemService {

	@Autowired
	private ItemRepository itemRepo;
	

	
	//4-2   List all the Item
	public List<Item> allItems(){
		return itemRepo.findAll();
	}
	
    //Find user by id
	public Item findById(Long id) {
		
		return itemRepo.findById(id).orElse(null);
	}
	
	//4-3 retrieves a Item
	public Item findItem(Long itemId) {
		Optional<Item> optionalItem = itemRepo.findById(itemId);
		
		if(optionalItem.isPresent()) {
			return optionalItem.get();
		}
		else {
			return null;
		}
	} 
	
	 //4-4    creates a Item
		public Item creatItem(Item p) {
			return itemRepo.save(p);
		}
	
		public Item saveItem(@Valid Item item) {
			 
			return itemRepo.save(item);
		}

		// cam
		public void addUser(Item item, User c) {
			c.getItems().add(item);
			itemRepo.save(item);
		}
	
		//delete
		public void deleteItem(Long id) {
			itemRepo.deleteById(id);
		}
		

 
//		public List<Item> allItems( String keyword ) {
//			Sort sort Sort.by(sortField);
//			sort = sortDir.equals("asc") ? sort.ascending() : sort.descending();
//			
//			Pageable pageable = PagRequest.of(pageNumber - 1, 6 , sort);
//			if(keyword != null) {
//				return itemRepo.findAll(keyword, pageable);
//			}
//			return itemRepo.findAll();
//		}
		
 
 	
}
