package com.second.fruitStore;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FruitStoreApplicationTests {

	@Test
	void contextLoads() {
	}

}
