package com.second.studRoster;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StudRosterApplicationTests {

	@Test
	void contextLoads() {
	}

}
