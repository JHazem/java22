package com.second.productCategory.repositories;

import java.util.List;

import org.springframework.data.repository.CrudRepository;

import com.second.productCategory.models.Category;
import com.second.productCategory.models.Product;

public interface CategoryRepository extends CrudRepository<Category, Long> {
	
	
	 
    List<Category> findAllByProducts(Product product);
    
     
    List<Category> findByProductsNotContains(Product product);

}
