package com.second.solo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SoloApplication {

	public static void main(String[] args) {
		SpringApplication.run(SoloApplication.class, args);
	}

}
