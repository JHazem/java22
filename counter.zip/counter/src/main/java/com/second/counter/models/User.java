package com.second.counter.models;

public class User {

}
