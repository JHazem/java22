package com.second.solo.repositories;

import java.util.List;
 
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.second.solo.models.Item; 

@Repository
public interface ItemRepository extends CrudRepository<Item, Long>{
 
//    List<Item> findAllByUser(User user);
   
//    List<Item> findByUserIsNot(User user);
 
	List<Item> findAll();
	
	
	
//	@Query("SELECT p FORM Item p WHERE  "
//			+ "CONCAT(p.id, p.itemName, p.description,  p.posted )"
//			+ "LIKE %?1%")
//public List<Item> findAll(String keyword);  

}
 