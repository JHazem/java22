package com.second.human;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HumanApplicationTests {

	@Test
	void contextLoads() {
	}

}
