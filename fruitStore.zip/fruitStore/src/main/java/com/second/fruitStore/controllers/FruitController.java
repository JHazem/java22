package com.second.fruitStore.controllers;

public class FruitController {

}
