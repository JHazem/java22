package com.second.displayDate.controllers;


import org.springframework.stereotype.Controller;

import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class DisplayController {
	
	@RequestMapping("/")
	public String dashboard() {
		return "dashTime.jsp";
	}
	
	@RequestMapping("/date")
	public String dateDash() {

		return "Date.jsp";
	}
	
	@RequestMapping("/time")
	public String timeDash() {
		
		return "Time.jsp";
	}

}
