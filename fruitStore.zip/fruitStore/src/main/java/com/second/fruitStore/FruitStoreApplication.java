package com.second.fruitStore;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FruitStoreApplication {

	public static void main(String[] args) {
		SpringApplication.run(FruitStoreApplication.class, args);
	}

}
