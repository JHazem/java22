package com.second.testexam;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TestexamApplication {

	public static void main(String[] args) {
		SpringApplication.run(TestexamApplication.class, args);
	}

}
