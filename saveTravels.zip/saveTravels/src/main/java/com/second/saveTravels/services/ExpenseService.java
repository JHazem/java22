package com.second.saveTravels.services;

import java.util.List;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.second.saveTravels.models.Expense;
import com.second.saveTravels.repositories.ExpenseRepository;

@Service
public class ExpenseService {
	
	@Autowired
	private ExpenseRepository expRepository;
	
	// returns all the expense
	public List<Expense> allExpenses(){
		return expRepository.findAll();
	}
	
    // creates a expense
    public Expense createExpense(Expense e) {
        return expRepository.save(e);
    }
    
    public Expense update(Expense e) {
        return expRepository.save(e);
    }

    // retrieves
    public Expense findExpense(Long id) {
    	
        Optional<Expense> optionalExpense = expRepository.findById(id);
        
        if(optionalExpense.isPresent()) {
            return optionalExpense.get();
                 
        } else {
            return null;
        } 
    }
    
	public void deleteExpense(Long id) {
		expRepository.deleteById(id);
	}
	
	public Expense updateExpense( Long id,
									String  exp,
									String  vender,
									Integer amount) {
		return null;
	}
    
	public void updateExpense(Expense exp) {
		// TODO Auto-generated method stub
		expRepository.save(exp);
	}
}
