package com.second.ninjaGame;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class NinjaGameApplication {

	public static void main(String[] args) {
		SpringApplication.run(NinjaGameApplication.class, args);
	}

}
